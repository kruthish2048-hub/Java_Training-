package dao;

import db.DBConnection;
import model.OrderItem;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {

    /** Creates a new order for a customer and returns the generated order_id. */
    public int createOrder(int customerId) {
        String sql = "INSERT INTO Orders (customer_id, order_date) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, customerId);
            ps.setDate(2, Date.valueOf(LocalDate.now()));
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Error creating order: " + e.getMessage());
        }
        return -1;
    }

    /** Adds a product line to an order and decrements stock atomically. Returns false if stock is insufficient. */
    public boolean addOrderItem(int orderId, int productId, int quantity, double price) {
        String insertItem = "INSERT INTO Order_Items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            ProductDAO productDAO = new ProductDAO();
            boolean stockOk = productDAO.reduceStock(productId, quantity, conn);
            if (!stockOk) {
                conn.rollback();
                System.out.println("Insufficient stock for product ID " + productId);
                return false;
            }

            try (PreparedStatement ps = conn.prepareStatement(insertItem)) {
                ps.setInt(1, orderId);
                ps.setInt(2, productId);
                ps.setInt(3, quantity);
                ps.setDouble(4, price);
                ps.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            System.err.println("Error adding order item: " + e.getMessage());
            try { if (conn != null) conn.rollback(); } catch (SQLException ignored) {}
            return false;
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException ignored) {}
        }
    }

    public List<OrderItem> getOrderItems(int orderId) {
        List<OrderItem> items = new ArrayList<>();
        String sql = "SELECT * FROM Order_Items WHERE order_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    items.add(new OrderItem(
                            rs.getInt("item_id"), rs.getInt("order_id"),
                            rs.getInt("product_id"), rs.getInt("quantity"), rs.getDouble("price")));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching order items: " + e.getMessage());
        }
        return items;
    }

    public double calculateBill(int orderId) {
        double total = 0;
        for (OrderItem item : getOrderItems(orderId)) {
            total += item.getSubtotal();
        }
        return total;
    }

    // ---------- Reports ----------

    public double getTotalSales() {
        String sql = "SELECT SUM(quantity * price) AS total FROM Order_Items";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble("total");
        } catch (SQLException e) {
            System.err.println("Error computing total sales: " + e.getMessage());
        }
        return 0;
    }

    public List<String> getBestSellingProducts(int limit) {
        List<String> results = new ArrayList<>();
        String sql = "SELECT p.product_name, SUM(oi.quantity) AS units_sold " +
                "FROM Order_Items oi INNER JOIN Products p ON oi.product_id = p.product_id " +
                "GROUP BY p.product_id, p.product_name " +
                "ORDER BY units_sold DESC LIMIT ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(String.format("%-25s Units Sold: %d",
                            rs.getString("product_name"), rs.getInt("units_sold")));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error computing best sellers: " + e.getMessage());
        }
        return results;
    }

    /** INNER JOIN: full purchase history joining Customers, Orders, Order_Items, Products. */
    public List<String> getCustomerPurchaseReport() {
        List<String> results = new ArrayList<>();
        String sql = "SELECT c.customer_name, o.order_id, o.order_date, p.product_name, " +
                "oi.quantity, oi.price, (oi.quantity * oi.price) AS subtotal " +
                "FROM Customers c " +
                "INNER JOIN Orders o ON c.customer_id = o.customer_id " +
                "INNER JOIN Order_Items oi ON o.order_id = oi.order_id " +
                "INNER JOIN Products p ON oi.product_id = p.product_id " +
                "ORDER BY c.customer_name, o.order_id";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                results.add(String.format("%-20s Order#%-5d %-10s %-20s Qty:%-4d Price:%-8.2f Subtotal:%-10.2f",
                        rs.getString("customer_name"), rs.getInt("order_id"),
                        rs.getDate("order_date").toString(), rs.getString("product_name"),
                        rs.getInt("quantity"), rs.getDouble("price"), rs.getDouble("subtotal")));
            }
        } catch (SQLException e) {
            System.err.println("Error generating customer purchase report: " + e.getMessage());
        }
        return results;
    }

    /** LEFT JOIN: customers who have never placed an order. */
    public List<String> getCustomersWithoutOrders() {
        List<String> results = new ArrayList<>();
        String sql = "SELECT c.customer_id, c.customer_name, c.email " +
                "FROM Customers c " +
                "LEFT JOIN Orders o ON c.customer_id = o.customer_id " +
                "WHERE o.order_id IS NULL";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                results.add(String.format("ID:%-5d %-20s %-25s",
                        rs.getInt("customer_id"), rs.getString("customer_name"), rs.getString("email")));
            }
        } catch (SQLException e) {
            System.err.println("Error generating customers-without-orders report: " + e.getMessage());
        }
        return results;
    }

    /** GROUP BY + SUM: top customers ranked by total amount spent. */
    public List<String> getTopCustomers(int limit) {
        List<String> results = new ArrayList<>();
        String sql = "SELECT c.customer_name, SUM(oi.quantity * oi.price) AS total_spent, " +
                "COUNT(DISTINCT o.order_id) AS order_count " +
                "FROM Customers c " +
                "INNER JOIN Orders o ON c.customer_id = o.customer_id " +
                "INNER JOIN Order_Items oi ON o.order_id = oi.order_id " +
                "GROUP BY c.customer_id, c.customer_name " +
                "ORDER BY total_spent DESC LIMIT ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(String.format("%-20s Total Spent: %-12.2f Orders: %d",
                            rs.getString("customer_name"), rs.getDouble("total_spent"),
                            rs.getInt("order_count")));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error generating top customers report: " + e.getMessage());
        }
        return results;
    }

    /** Bonus: Monthly sales report using aggregate functions grouped by month. */
    public List<String> getMonthlySalesReport() {
        List<String> results = new ArrayList<>();
        String sql = "SELECT DATE_FORMAT(o.order_date, '%Y-%m') AS month, " +
                "SUM(oi.quantity * oi.price) AS total, COUNT(DISTINCT o.order_id) AS orders, " +
                "AVG(oi.quantity * oi.price) AS avg_item_value, MAX(oi.quantity * oi.price) AS max_item_value, " +
                "MIN(oi.quantity * oi.price) AS min_item_value " +
                "FROM Orders o INNER JOIN Order_Items oi ON o.order_id = oi.order_id " +
                "GROUP BY month ORDER BY month";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                results.add(String.format("%-10s Total:%-12.2f Orders:%-5d Avg:%-10.2f Max:%-10.2f Min:%-10.2f",
                        rs.getString("month"), rs.getDouble("total"), rs.getInt("orders"),
                        rs.getDouble("avg_item_value"), rs.getDouble("max_item_value"), rs.getDouble("min_item_value")));
            }
        } catch (SQLException e) {
            System.err.println("Error generating monthly sales report: " + e.getMessage());
        }
        return results;
    }
}
