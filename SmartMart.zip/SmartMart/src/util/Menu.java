package util;

import dao.CustomerDAO;
import dao.OrderDAO;
import dao.ProductDAO;
import model.Customer;
import model.Product;
import service.SalesService;

import java.util.List;
import java.util.Scanner;

public class Menu {

    private final Scanner sc = new Scanner(System.in);
    private final CustomerDAO customerDAO = new CustomerDAO();
    private final ProductDAO productDAO = new ProductDAO();
    private final OrderDAO orderDAO = new OrderDAO();
    private final SalesService salesService = new SalesService();

    public void start() {
        boolean running = true;
        while (running) {
            System.out.println("\n================ MAIN MENU ================");
            System.out.println("1. Customer Management");
            System.out.println("2. Product Management");
            System.out.println("3. Order Management");
            System.out.println("4. Reports");
            System.out.println("5. Exit");
            System.out.println("============================================");
            int choice = InputValidator.readInt(sc, "Enter choice: ");
            switch (choice) {
                case 1 -> customerMenu();
                case 2 -> productMenu();
                case 3 -> orderMenu();
                case 4 -> reportMenu();
                case 5 -> running = false;
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
        System.out.println("Thank you for using SmartMart. Goodbye!");
    }

    // ---------------- Customer Management ----------------
    private void customerMenu() {
        System.out.println("\n--- Customer Management ---");
        System.out.println("1. Add Customer");
        System.out.println("2. Update Customer");
        System.out.println("3. Delete Customer");
        System.out.println("4. Search Customer");
        System.out.println("5. View All Customers");
        System.out.println("6. Back");
        int choice = InputValidator.readInt(sc, "Enter choice: ");
        switch (choice) {
            case 1 -> {
                String name = InputValidator.readNonEmpty(sc, "Name: ");
                String phone = InputValidator.readPhone(sc, "Phone: ");
                String email = InputValidator.readEmail(sc, "Email: ");
                String city = InputValidator.readNonEmpty(sc, "City: ");
                boolean ok = customerDAO.addCustomer(new Customer(name, phone, email, city));
                System.out.println(ok ? "Customer added." : "Failed to add customer.");
            }
            case 2 -> {
                int id = InputValidator.readInt(sc, "Customer ID to update: ");
                Customer existing = customerDAO.getCustomerById(id);
                if (existing == null) { System.out.println("Customer not found."); return; }
                String name = InputValidator.readNonEmpty(sc, "New Name: ");
                String phone = InputValidator.readPhone(sc, "New Phone: ");
                String email = InputValidator.readEmail(sc, "New Email: ");
                String city = InputValidator.readNonEmpty(sc, "New City: ");
                boolean ok = customerDAO.updateCustomer(new Customer(id, name, phone, email, city));
                System.out.println(ok ? "Customer updated." : "Update failed.");
            }
            case 3 -> {
                int id = InputValidator.readInt(sc, "Customer ID to delete: ");
                boolean ok = customerDAO.deleteCustomer(id);
                System.out.println(ok ? "Customer deleted." : "Delete failed.");
            }
            case 4 -> {
                String name = InputValidator.readNonEmpty(sc, "Search by name: ");
                List<Customer> results = customerDAO.searchCustomerByName(name);
                printCustomers(results);
            }
            case 5 -> printCustomers(customerDAO.getAllCustomers());
            case 6 -> { /* back */ }
            default -> System.out.println("Invalid choice.");
        }
    }

    private void printCustomers(List<Customer> customers) {
        if (customers.isEmpty()) { System.out.println("No customers found."); return; }
        System.out.printf("%-5s %-20s %-15s %-25s %-15s%n", "ID", "Name", "Phone", "Email", "City");
        customers.forEach(System.out::println);
    }

    // ---------------- Product Management ----------------
    private void productMenu() {
        System.out.println("\n--- Product Management ---");
        System.out.println("1. Add Product");
        System.out.println("2. Update Product");
        System.out.println("3. Delete Product");
        System.out.println("4. Search Product");
        System.out.println("5. View All Products");
        System.out.println("6. Low Stock Alert");
        System.out.println("7. Back");
        int choice = InputValidator.readInt(sc, "Enter choice: ");
        switch (choice) {
            case 1 -> {
                String name = InputValidator.readNonEmpty(sc, "Product Name: ");
                String category = InputValidator.readNonEmpty(sc, "Category: ");
                double price = InputValidator.readDouble(sc, "Price: ");
                int stock = InputValidator.readInt(sc, "Stock: ");
                boolean ok = productDAO.addProduct(new Product(name, category, price, stock));
                System.out.println(ok ? "Product added." : "Failed to add product.");
            }
            case 2 -> {
                int id = InputValidator.readInt(sc, "Product ID to update: ");
                Product existing = productDAO.getProductById(id);
                if (existing == null) { System.out.println("Product not found."); return; }
                String name = InputValidator.readNonEmpty(sc, "New Name: ");
                String category = InputValidator.readNonEmpty(sc, "New Category: ");
                double price = InputValidator.readDouble(sc, "New Price: ");
                int stock = InputValidator.readInt(sc, "New Stock: ");
                boolean ok = productDAO.updateProduct(new Product(id, name, category, price, stock));
                System.out.println(ok ? "Product updated." : "Update failed.");
            }
            case 3 -> {
                int id = InputValidator.readInt(sc, "Product ID to delete: ");
                boolean ok = productDAO.deleteProduct(id);
                System.out.println(ok ? "Product deleted." : "Delete failed.");
            }
            case 4 -> {
                String name = InputValidator.readNonEmpty(sc, "Search by name: ");
                printProducts(productDAO.searchProductByName(name));
            }
            case 5 -> printProducts(productDAO.getAllProducts());
            case 6 -> {
                int threshold = InputValidator.readInt(sc, "Alert threshold (e.g. 5): ");
                List<Product> low = productDAO.getLowStockProducts(threshold);
                if (low.isEmpty()) System.out.println("No products below threshold.");
                else { System.out.println("LOW STOCK PRODUCTS:"); printProducts(low); }
            }
            case 7 -> { /* back */ }
            default -> System.out.println("Invalid choice.");
        }
    }

    private void printProducts(List<Product> products) {
        if (products.isEmpty()) { System.out.println("No products found."); return; }
        System.out.printf("%-5s %-20s %-15s %-10s %-10s%n", "ID", "Name", "Category", "Price", "Stock");
        products.forEach(System.out::println);
    }

    // ---------------- Order Management ----------------
    private void orderMenu() {
        System.out.println("\n--- Order Management ---");
        System.out.println("1. Create New Order");
        System.out.println("2. Back");
        int choice = InputValidator.readInt(sc, "Enter choice: ");
        if (choice == 2) return;
        if (choice != 1) { System.out.println("Invalid choice."); return; }

        int customerId = InputValidator.readInt(sc, "Customer ID: ");
        Customer customer = customerDAO.getCustomerById(customerId);
        if (customer == null) { System.out.println("Customer not found."); return; }

        int orderId = salesService.startNewOrder(customerId);
        if (orderId == -1) { System.out.println("Failed to create order."); return; }
        System.out.println("Order #" + orderId + " created for " + customer.getCustomerName());

        boolean addingItems = true;
        while (addingItems) {
            System.out.println("\nAvailable products:");
            printProducts(productDAO.getAllProducts());
            int productId = InputValidator.readInt(sc, "Product ID to add (0 to finish): ");
            if (productId == 0) { addingItems = false; continue; }
            int qty = InputValidator.readInt(sc, "Quantity: ");
            salesService.addProductToOrder(orderId, productId, qty);

            String more = InputValidator.readNonEmpty(sc, "Add another product? (y/n): ");
            if (!more.equalsIgnoreCase("y")) addingItems = false;
        }

        salesService.printInvoice(orderId, customer.getCustomerName());
    }

    // ---------------- Reports ----------------
    private void reportMenu() {
        System.out.println("\n--- Reports ---");
        System.out.println("1. Total Sales");
        System.out.println("2. Best Selling Products");
        System.out.println("3. Customer Purchase Report (INNER JOIN)");
        System.out.println("4. Customers Without Orders (LEFT JOIN)");
        System.out.println("5. Top Customers (GROUP BY, SUM)");
        System.out.println("6. Monthly Sales Report (Bonus)");
        System.out.println("7. Back");
        int choice = InputValidator.readInt(sc, "Enter choice: ");
        switch (choice) {
            case 1 -> System.out.printf("Total Sales: %.2f%n", orderDAO.getTotalSales());
            case 2 -> printList(orderDAO.getBestSellingProducts(5), "No sales data yet.");
            case 3 -> printList(orderDAO.getCustomerPurchaseReport(), "No purchase data yet.");
            case 4 -> printList(orderDAO.getCustomersWithoutOrders(), "Every customer has placed an order.");
            case 5 -> printList(orderDAO.getTopCustomers(5), "No sales data yet.");
            case 6 -> printList(orderDAO.getMonthlySalesReport(), "No sales data yet.");
            case 7 -> { /* back */ }
            default -> System.out.println("Invalid choice.");
        }
    }

    private void printList(List<String> lines, String emptyMessage) {
        if (lines.isEmpty()) { System.out.println(emptyMessage); return; }
        lines.forEach(System.out::println);
    }
}
