package util;

import java.util.Scanner;

/**
 * Bonus feature: simple console login gate.
 * Credentials are intentionally simple for this mini project; in a real
 * system these would be hashed and stored in a Users table.
 */
public class LoginManager {

    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";
    private static final int MAX_ATTEMPTS = 3;

    public static boolean login(Scanner sc) {
        System.out.println("=========================================");
        System.out.println("   SmartMart - Sales & Inventory System");
        System.out.println("=========================================");
        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            System.out.print("Username: ");
            String user = sc.nextLine().trim();
            System.out.print("Password: ");
            String pass = sc.nextLine().trim();

            if (ADMIN_USERNAME.equals(user) && ADMIN_PASSWORD.equals(pass)) {
                System.out.println("Login successful. Welcome, " + user + "!\n");
                return true;
            }
            System.out.println("Invalid credentials. Attempts left: " + (MAX_ATTEMPTS - attempt));
        }
        System.out.println("Too many failed attempts. Exiting.");
        return false;
    }
}
