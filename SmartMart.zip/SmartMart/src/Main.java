import util.LoginManager;
import util.Menu;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        if (!LoginManager.login(sc)) {
            return;
        }
        new Menu().start();
    }
}
