package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Handles the single JDBC connection used across the application.
 * Update DB_URL, DB_USER and DB_PASSWORD to match your local MySQL setup,
 * or set them via environment variables (recommended for real use).
 */
public class DBConnection {

    private static final String DB_URL =
            System.getenv().getOrDefault("SMARTMART_DB_URL",
                    "jdbc:mysql://localhost:3306/smartmart_db?useSSL=false&serverTimezone=UTC");
    private static final String DB_USER =
            System.getenv().getOrDefault("SMARTMART_DB_USER", "root");
    private static final String DB_PASSWORD =
            System.getenv().getOrDefault("SMARTMART_DB_PASSWORD", "root");

    private static Connection connection;

    private DBConnection() {}

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException("MySQL JDBC Driver not found on classpath. " +
                        "Download mysql-connector-j and add it to lib/. See README.md", e);
            }
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        }
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}
