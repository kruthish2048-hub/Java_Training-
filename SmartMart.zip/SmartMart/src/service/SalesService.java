package service;

import dao.OrderDAO;
import dao.ProductDAO;
import model.OrderItem;
import model.Product;

import java.util.List;

/**
 * Orchestrates the order workflow: order creation, adding line items with
 * stock validation, bill calculation and invoice generation.
 */
public class SalesService {

    private final OrderDAO orderDAO = new OrderDAO();
    private final ProductDAO productDAO = new ProductDAO();

    public int startNewOrder(int customerId) {
        return orderDAO.createOrder(customerId);
    }

    public boolean addProductToOrder(int orderId, int productId, int quantity) {
        Product product = productDAO.getProductById(productId);
        if (product == null) {
            System.out.println("Product not found.");
            return false;
        }
        if (product.getStock() < quantity) {
            System.out.println("Not enough stock. Available: " + product.getStock());
            return false;
        }
        return orderDAO.addOrderItem(orderId, productId, quantity, product.getPrice());
    }

    public double calculateBill(int orderId) {
        return orderDAO.calculateBill(orderId);
    }

    public void printInvoice(int orderId, String customerName) {
        List<OrderItem> items = orderDAO.getOrderItems(orderId);
        System.out.println("\n===================== INVOICE =====================");
        System.out.println("Order ID   : " + orderId);
        System.out.println("Customer   : " + customerName);
        System.out.println("-----------------------------------------------------");
        System.out.printf("%-25s %-8s %-10s %-10s%n", "Product ID", "Qty", "Price", "Subtotal");
        double total = 0;
        for (OrderItem item : items) {
            System.out.printf("%-25s %-8d %-10.2f %-10.2f%n",
                    item.getProductId(), item.getQuantity(), item.getPrice(), item.getSubtotal());
            total += item.getSubtotal();
        }
        System.out.println("-----------------------------------------------------");
        System.out.printf("TOTAL: %.2f%n", total);
        System.out.println("=====================================================\n");
    }
}
