-- =====================================================================
-- SmartMart Sales & Inventory Management System
-- Database schema + sample data
-- =====================================================================

CREATE DATABASE IF NOT EXISTS smartmart_db;
USE smartmart_db;

DROP TABLE IF EXISTS Order_Items;
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Customers;

CREATE TABLE Customers (
    customer_id   INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    phone         VARCHAR(20),
    email         VARCHAR(100),
    city          VARCHAR(50)
);

CREATE TABLE Products (
    product_id    INT AUTO_INCREMENT PRIMARY KEY,
    product_name  VARCHAR(100) NOT NULL,
    category      VARCHAR(50),
    price         DECIMAL(10, 2) NOT NULL DEFAULT 0,
    stock         INT NOT NULL DEFAULT 0
);

CREATE TABLE Orders (
    order_id      INT AUTO_INCREMENT PRIMARY KEY,
    customer_id   INT NOT NULL,
    order_date    DATE NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE
);

CREATE TABLE Order_Items (
    item_id       INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT NOT NULL,
    product_id    INT NOT NULL,
    quantity      INT NOT NULL,
    price         DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- =====================================================================
-- Sample data (optional) - lets reports return meaningful results
-- immediately after setup.
-- =====================================================================

INSERT INTO Customers (customer_name, phone, email, city) VALUES
('Aditi Rao', '9876543210', 'aditi.rao@example.com', 'Hyderabad'),
('Rahul Mehta', '9123456780', 'rahul.mehta@example.com', 'Bengaluru'),
('Priya Nair', '9988776655', 'priya.nair@example.com', 'Chennai'),
('Sanjay Gupta', '9871234560', 'sanjay.gupta@example.com', 'Mumbai'),
('Neha Verma', '9012345678', 'neha.verma@example.com', 'Hyderabad');

INSERT INTO Products (product_name, category, price, stock) VALUES
('Wireless Mouse', 'Electronics', 599.00, 50),
('Mechanical Keyboard', 'Electronics', 2499.00, 30),
('Notebook A5', 'Stationery', 45.00, 200),
('Ball Pen (Pack of 10)', 'Stationery', 60.00, 150),
('Water Bottle 1L', 'Home', 249.00, 80),
('LED Desk Lamp', 'Home', 899.00, 4),
('USB-C Cable', 'Electronics', 199.00, 100);

INSERT INTO Orders (customer_id, order_date) VALUES
(1, '2026-06-01'),
(2, '2026-06-03'),
(1, '2026-06-15'),
(3, '2026-07-02'),
(2, '2026-07-10');

INSERT INTO Order_Items (order_id, product_id, quantity, price) VALUES
(1, 1, 2, 599.00),
(1, 3, 5, 45.00),
(2, 2, 1, 2499.00),
(3, 4, 3, 60.00),
(3, 7, 2, 199.00),
(4, 5, 1, 249.00),
(5, 2, 1, 2499.00),
(5, 6, 1, 899.00);

-- Note: Customer 'Sanjay Gupta' and 'Neha Verma' intentionally have
-- fewer/no orders so the "Customers Without Orders" (LEFT JOIN) report
-- has something to show.
