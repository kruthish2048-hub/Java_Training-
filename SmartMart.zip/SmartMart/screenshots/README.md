Add your console screenshots here after running the application, e.g.:

- 01_main_menu.png
- 02_add_customer.png
- 03_create_order_invoice.png
- 04_reports.png

These are referenced from the project's root README.md.
