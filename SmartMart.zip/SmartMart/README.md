# SmartMart — Sales & Inventory Management System

A Java console application for managing customers, products, and orders for
a small retail business, backed by a MySQL database via JDBC. Built as a
mini project to demonstrate Java OOP, JDBC, SQL joins/aggregates, and
modular application design.

## Technologies Used

- Java (JDK 17+ recommended, works on 8+)
- JDBC (`java.sql`)
- MySQL 8
- Git & GitHub
- Any IDE (IntelliJ IDEA / VS Code) or plain `javac`/`java` on the CLI

## Project Structure

```
SmartMart/
├── src/
│   ├── model/          # Customer, Product, Order, OrderItem (POJOs)
│   ├── dao/             # CustomerDAO, ProductDAO, OrderDAO (JDBC CRUD + reports)
│   ├── db/               # DBConnection (single connection manager)
│   ├── service/          # SalesService (order workflow orchestration)
│   ├── util/              # Menu (console UI), InputValidator, LoginManager
│   └── Main.java          # Entry point
├── database.sql            # Schema + sample data
├── lib/                      # Put mysql-connector-j-x.x.x.jar here (not committed)
├── screenshots/                # Console screenshots
├── .gitignore
└── README.md
```

## Features

**Customer Management** — Add, Update, Delete, Search (by name), View All

**Product Management** — Add, Update, Delete, Search (by name), View All,
Low Stock Alert (bonus)

**Order Management** — Create an order for a customer, add multiple
products to it (stock is validated and decremented atomically per line
item), auto-calculate the bill, print a formatted invoice

**Reports**
- Total Sales
- Best Selling Products
- Customer Purchase Report (`INNER JOIN` across Customers → Orders →
  Order_Items → Products)
- Customers Without Orders (`LEFT JOIN`)
- Top Customers (`GROUP BY` + `SUM`, ranked by total spend)
- Monthly Sales Report — bonus (`GROUP BY` month with `SUM`, `AVG`, `MAX`,
  `MIN`, `COUNT`)

**Bonus features implemented**
- Simple login gate (`admin` / `admin123`, 3 attempts) before the main menu
- Low stock alert with configurable threshold
- Monthly sales report
- Centralized input validation (`InputValidator`) for numbers, non-empty
  text, email format, and phone number format

## Database Schema

| Table          | Columns                                                              |
|----------------|-----------------------------------------------------------------------|
| `Customers`    | customer_id (PK), customer_name, phone, email, city                   |
| `Products`     | product_id (PK), product_name, category, price, stock                 |
| `Orders`       | order_id (PK), customer_id (FK), order_date                           |
| `Order_Items`  | item_id (PK), order_id (FK), product_id (FK), quantity, price         |

Foreign keys enforce referential integrity (`Orders.customer_id` and
`Order_Items.order_id/product_id`), and `Order_Items` deletes cascade when
an order or customer is removed. See [`database.sql`](database.sql) for the
full DDL and sample rows.

## SQL Concepts Used

`INSERT`, `UPDATE`, `DELETE`, `SELECT`, `INNER JOIN`, `LEFT JOIN`,
`COUNT()`, `SUM()`, `AVG()`, `MAX()`, `MIN()`, `GROUP BY`, `ORDER BY`,
`PreparedStatement` (used everywhere data is written or filtered, to
prevent SQL injection).

## Setup & Run

### 1. Prerequisites
- JDK installed (`java -version`)
- MySQL Server running locally (or reachable remotely)
- MySQL Connector/J driver jar — [download here](https://dev.mysql.com/downloads/connector/j/)

### 2. Create the database
```bash
mysql -u root -p < database.sql
```
This creates the `smartmart_db` database, all four tables, and inserts
sample rows so the reports return meaningful data immediately.

### 3. Configure the connection
`src/db/DBConnection.java` reads connection details from environment
variables, with sensible local defaults:

| Variable               | Default                                                              |
|------------------------|-----------------------------------------------------------------------|
| `SMARTMART_DB_URL`     | `jdbc:mysql://localhost:3306/smartmart_db?useSSL=false&serverTimezone=UTC` |
| `SMARTMART_DB_USER`    | `root`                                                                 |
| `SMARTMART_DB_PASSWORD`| `root`                                                                 |

Either export these before running, or just edit the defaults directly in
`DBConnection.java` for local testing.

### 4. Compile and run

Place the downloaded connector jar in a `lib/` folder at the project root
(e.g. `lib/mysql-connector-j-8.4.0.jar`), then:

```bash
# From the project root
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp "out:lib/mysql-connector-j-8.4.0.jar" Main
```

On Windows, use `;` instead of `:` in the classpath:
```powershell
java -cp "out;lib\mysql-connector-j-8.4.0.jar" Main
```

**Default login:** username `admin`, password `admin123`.

### Using an IDE instead
Import the `src` folder as the source root, add the MySQL connector jar as
a project library/dependency, then run `Main.java` directly.

## Screenshots

Add screenshots of the running application to the [`screenshots/`](screenshots)
folder (main menu, a customer/product operation, an order + invoice, and a
report) and reference them here, e.g.:

```
![Main Menu](screenshots/01_main_menu.png)
![Invoice](screenshots/03_create_order_invoice.png)
```

## Design Notes

- **Layered architecture**: `model` (data) → `dao` (persistence) →
  `service` (business logic) → `util`/`Main` (presentation), so each layer
  has one responsibility and is easy to test or swap out independently.
- **PreparedStatement everywhere** user input reaches SQL, to eliminate
  SQL injection risk.
- **Stock decrement is transactional**: `OrderDAO.addOrderItem` disables
  auto-commit, decrements stock only if enough is available, inserts the
  order line, then commits — rolling back on any failure so stock and
  order data never go out of sync.
- **Environment-based config** for DB credentials keeps secrets out of
  source control (see `.gitignore`).

## Known Limitations / Next Steps

- Single hardcoded admin login rather than a full `Users` table with
  hashed passwords — acceptable for a mini project, flagged here as the
  natural next step for a production version.
- No automated tests included; manual verification via the console menu
  and the sample data in `database.sql` was used during development.
- Invoice output goes to the console only (no PDF/file export).
